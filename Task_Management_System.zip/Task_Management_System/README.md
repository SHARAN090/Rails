# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...
<<<<<<< HEAD
=======
# Task_Management_System
>>>>>>> 85cd8c78c2ace4d1feda77b6ae64b7c31abe8637
